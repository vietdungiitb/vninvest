vninvestcharts-widget
Copyright 2026 Pham Viet Dung

Licensed under the Mozilla Public License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at https://mozilla.org/MPL/2.0/.

This Source Code Form is "Incompatible With Secondary Licenses", as defined
by the Mozilla Public License, v. 2.0.

This product bundles software developed at vninvestcharts-engine:

  @vninvestcharts/engine-core      Apache-2.0
  @vninvestcharts/engine-drawing   Apache-2.0
  @vninvestcharts/engine-react     Apache-2.0

The engine packages incorporate a controlled fork of KLineCharts
(Apache-2.0, pinned at v9.8.12).

--------------------------------------------------------------------------------
Third-party dependencies distributed in `dist/`
--------------------------------------------------------------------------------

Regenerate this table with:  npm run audit:license -- --write
Re-verify it (exit 0 = consistent):  npm run audit:license

Every entry is read from the installed package's own `package.json`, and the gate
fails if this table drifts from the tree. It was computed rather than typed
because the hand-written version this replaces was already wrong: it listed
`authenticator` as ISC, while the package declared `(MIT OR Apache-2.0)`, and
nothing had ever compared the two.

`authenticator` and `@emotion/is-prop-valid` were removed on 2026-10-11 (ledger
`F04_UNUSED_PROD_DEPS_REMOVED_2026-10-11`): both were declared as runtime
dependencies with **0 imports** anywhere in the repo or in `dist/`.
`authenticator` is additionally a Node CLI (`bin`, deps `authenticator-cli`,
`notp`, `thirty-two`) — a TOTP/MFA tool with no use in a browser charting
library, and it dragged eleven transitive packages into every consumer's
install. The paragraph above is kept as the record of why the table is
generated: the original defect it describes is what motivated the gate.

```
  @monaco-editor/react            MIT
  @vninvestcharts/engine-core     Apache-2.0
  @vninvestcharts/engine-drawing  Apache-2.0
  @vninvestcharts/engine-react    Apache-2.0
  d3-array                        ISC
  d3-force                        ISC
  d3-format                       ISC
  d3-interpolate                  ISC
  d3-path                         ISC
  d3-scale                        ISC
  d3-scale-chromatic              ISC
  d3-selection                    ISC
  d3-shape                        ISC
  d3-time                         ISC
  d3-time-format                  ISC
  lodash.flattendeep              MIT
  monaco-editor                   MIT
  prop-types                      MIT
  react                           MIT
  react-dom                       MIT
  save-svg-as-png                 MIT
```

Per Apache-2.0 §4(d), the full licence text of every bundled dependency travels
with the dependency itself, under `node_modules/<pkg>/LICENSE` after `npm install`.

--------------------------------------------------------------------------------
Package name, and the two Apache-2.0 release lines
--------------------------------------------------------------------------------

This package is published as **`@vninvestcharts/widget`**.

It is NOT published as `vninvestcharts-widget`. That name already exists on npm at
`1.4.0`, published under **MPL-2.0**. Publishing Apache-2.0 bytes under the same name
would put two different licences behind one package identity, and npm does not allow
editing or replacing a published version - so the old line stays MPL-2.0 forever and a
new consumer installing the old name would silently get MPL-2.0 code.

Moving to the `@vninvestcharts/` scope puts this package alongside its own engine
(`@vninvestcharts/engine-core`, `-engine-drawing`, `-engine-react`, all Apache-2.0)
under one licence and one naming convention, and leaves the existing MPL-2.0 line
untouched.

**If you are upgrading from `vninvestcharts-widget` 1.4.0**, the package name changed.
See `docs/MIGRATION_0_2_0.md`. The import specifier changes from
`'vninvestcharts-widget'` to `'@vninvestcharts/widget'`; subpaths follow the same
pattern (`/adapters`, `/drawing`, `/types`, `/iframe-host`, `/iframe`).